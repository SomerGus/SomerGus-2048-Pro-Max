# 2048-godot
>a 2048 clone done in godot in C#.
Made it in one afternoon when i was bored.
![](2048.png)
